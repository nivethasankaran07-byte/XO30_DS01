export type EquipmentType = "H" | "L" | "M";

export interface SensorInput {
  airTemperature: number;
  processTemperature: number;
  rotationalSpeed: number;
  torque: number;
  toolWear: number;
  type: EquipmentType;
}

export interface RiskFactor {
  feature: string;
  contribution: number;
  value: string;
  unit: string;
  message: string;
  direction: "up" | "down";
}

export type RiskTier = "Low" | "Medium" | "High" | "Critical";

export interface Prediction extends SensorInput {
  equipmentId?: string;
  probability: number;
  tier: RiskTier;
  confidence: number;
  outOfRange: string[];
  explanation: string;
  factors: RiskFactor[];
  visualSignal?: number;
  combinedRisk?: number;
}

export const FEATURE_IMPORTANCE = [
  { feature: "Torque", short: "Torque", importance: 31, color: "#ff6b5f" },
  { feature: "Tool wear", short: "Tool wear", importance: 27, color: "#ffb454" },
  { feature: "Rotational speed", short: "RPM", importance: 22, color: "#7e8cff" },
  { feature: "Process temperature", short: "Process temp", importance: 12, color: "#61d7c4" },
  { feature: "Air temperature", short: "Air temp", importance: 8, color: "#82909d" },
];

export const TRAINING_RANGES = {
  airTemperature: [293, 305],
  processTemperature: [303, 315],
  rotationalSpeed: [1000, 2200],
  torque: [10, 75],
  toolWear: [0, 280],
} as const;

const clamp = (value: number, min = 0, max = 1) => Math.min(max, Math.max(min, value));
const fmt = (value: number, digits = 1) => Number(value.toFixed(digits));

function severity(value: number, low: number, high: number) {
  const highScore = Math.max(0, (value - high) / Math.max(1, high - low));
  const lowScore = Math.max(0, (low - value) / Math.max(1, high - low));
  return { high: highScore, low: lowScore };
}

export function predict(input: SensorInput, threshold = 0.18): Prediction {
  const air = severity(input.airTemperature, 296, 301);
  const process = severity(input.processTemperature, 306, 312);
  const rpm = severity(input.rotationalSpeed, 1250, 1750);
  const torque = severity(input.torque, 24, 54);
  const wear = severity(input.toolWear, 55, 190);

  const extremes = {
    "Air temperature": Math.max(air.high, air.low * 0.4),
    "Process temperature": Math.max(process.high, process.low * 0.35),
    "Rotational speed": Math.max(rpm.high, rpm.low * 0.35),
    Torque: Math.max(torque.high, torque.low * 0.35),
    "Tool wear": Math.max(wear.high, wear.low * 0.15),
  };

  const weighted =
    extremes["Air temperature"] * 0.16 +
    extremes["Process temperature"] * 0.18 +
    extremes["Rotational speed"] * 0.24 +
    extremes.Torque * 0.45 +
    extremes["Tool wear"] * 0.42;
  const coupledStress = torque.high > 0.35 && wear.high > 0.18 ? 0.28 : 0;
  const thermalStress = process.high > 0.3 && air.high > 0.25 ? 0.08 : 0;
  const typeAdjustment = input.type === "M" ? 0.012 : input.type === "H" ? 0.006 : 0;
  const probability = clamp(0.015 + weighted * 0.58 + coupledStress + thermalStress + typeAdjustment, 0.008, 0.985);

  const outOfRange: string[] = [];
  const ranges: [keyof typeof TRAINING_RANGES, number, string][] = [
    ["airTemperature", input.airTemperature, "Air temperature"],
    ["processTemperature", input.processTemperature, "Process temperature"],
    ["rotationalSpeed", input.rotationalSpeed, "Rotational speed"],
    ["torque", input.torque, "Torque"],
    ["toolWear", input.toolWear, "Tool wear"],
  ];
  ranges.forEach(([key, value, label]) => {
    const [min, max] = TRAINING_RANGES[key];
    if (value < min || value > max) outOfRange.push(label);
  });

  const factorData: RiskFactor[] = [
    {
      feature: "Torque",
      contribution: extremes.Torque * 0.45,
      value: `${fmt(input.torque)} Nm`,
      unit: "Nm",
      message:
        input.torque > 54
          ? `Torque is ${fmt(((input.torque - 54) / 54) * 100)}% above the upper operating range.`
          : input.torque < 24
            ? "Torque is below the normal operating range and should be checked against the current load."
            : "Torque is within the expected operating range.",
      direction: (input.torque > 54 ? "up" : "down") as "up" | "down",
    },
    {
      feature: "Tool wear",
      contribution: extremes["Tool wear"] * 0.42,
      value: `${fmt(input.toolWear, 0)} min`,
      unit: "min",
      message:
        input.toolWear > 190
          ? `Tool wear (${fmt(input.toolWear, 0)} min) is in the upper tail of observed values.`
          : "Tool wear is not an elevated driver in this assessment.",
      direction: (input.toolWear > 190 ? "up" : "down") as "up" | "down",
    },
    {
      feature: "Rotational speed",
      contribution: extremes["Rotational speed"] * 0.24,
      value: `${fmt(input.rotationalSpeed, 0)} rpm`,
      unit: "rpm",
      message:
        input.rotationalSpeed > 1750
          ? `Rotational speed is ${fmt(((input.rotationalSpeed - 1750) / 1750) * 100)}% above the normal band.`
          : input.rotationalSpeed < 1250
            ? "Rotational speed is below the normal band for this model."
            : "Rotational speed is inside the expected band.",
      direction: (input.rotationalSpeed > 1750 || input.rotationalSpeed < 1250 ? "up" : "down") as "up" | "down",
    },
    {
      feature: "Process temperature",
      contribution: extremes["Process temperature"] * 0.18,
      value: `${fmt(input.processTemperature)} K`,
      unit: "K",
      message:
        input.processTemperature > 312
          ? "Process temperature is elevated versus the observed operating envelope."
          : "Process temperature is within the expected operating envelope.",
      direction: (input.processTemperature > 312 ? "up" : "down") as "up" | "down",
    },
    {
      feature: "Air temperature",
      contribution: extremes["Air temperature"] * 0.16,
      value: `${fmt(input.airTemperature)} K`,
      unit: "K",
      message:
        input.airTemperature > 301
          ? "Air temperature is elevated versus the observed operating envelope."
          : "Air temperature is within the expected operating envelope.",
      direction: (input.airTemperature > 301 ? "up" : "down") as "up" | "down",
    },
  ]
    .map((factor) => ({ ...factor, contribution: clamp(factor.contribution / 0.7) }))
    .sort((a, b) => b.contribution - a.contribution);

  const activeFactors = factorData.filter((factor) => factor.contribution > 0.035);
  const highCount = activeFactors.filter((factor) => factor.direction === "up").length;
  const tier: RiskTier =
    probability >= threshold * 1.75 && highCount >= 2
      ? "Critical"
      : probability >= threshold * 1.05
        ? "High"
        : probability >= threshold * 0.55
          ? "Medium"
          : "Low";

  const confidence = clamp(0.61 + Math.abs(probability - threshold) * 0.76 - outOfRange.length * 0.08, 0.52, 0.97);
  const top = activeFactors.slice(0, 2);
  let explanation = "Observable readings are inside the learned operating envelope, so the model is not flagging a dominant driver.";
  if (top.length === 1) explanation = `${top[0].feature} is the main observable driver: ${top[0].message}`;
  if (top.length >= 2) explanation = `${top[0].feature} and ${top[1].feature} are the leading observable drivers. ${top[0].message} ${top[1].message}`;
  if (coupledStress && top.length >= 2) explanation = `Flagged high-risk: sustained high torque combined with elevated tool wear. ${top[0].message} ${top[1].message}`;

  return {
    ...input,
    probability,
    tier,
    confidence,
    outOfRange,
    explanation,
    factors: factorData,
  };
}

export const DEMO_ROWS: SensorInput[] = [
  { airTemperature: 300.9, processTemperature: 310.5, rotationalSpeed: 1875, torque: 66, toolWear: 238, type: "M" },
  { airTemperature: 301.8, processTemperature: 312.9, rotationalSpeed: 1760, torque: 60, toolWear: 221, type: "H" },
  { airTemperature: 299.8, processTemperature: 309.6, rotationalSpeed: 2020, torque: 72, toolWear: 194, type: "L" },
  { airTemperature: 303.1, processTemperature: 314.7, rotationalSpeed: 1820, torque: 58, toolWear: 267, type: "M" },
  { airTemperature: 300.4, processTemperature: 311.8, rotationalSpeed: 1735, torque: 53, toolWear: 188, type: "L" },
  { airTemperature: 298.8, processTemperature: 308.9, rotationalSpeed: 1640, torque: 49, toolWear: 176, type: "H" },
  { airTemperature: 302.1, processTemperature: 313.0, rotationalSpeed: 1685, torque: 47, toolWear: 210, type: "M" },
  { airTemperature: 296.8, processTemperature: 306.7, rotationalSpeed: 1940, torque: 44, toolWear: 144, type: "L" },
  { airTemperature: 299.4, processTemperature: 309.2, rotationalSpeed: 1515, torque: 42, toolWear: 120, type: "H" },
  { airTemperature: 297.6, processTemperature: 307.3, rotationalSpeed: 1610, torque: 38, toolWear: 90, type: "M" },
  { airTemperature: 298.2, processTemperature: 308.0, rotationalSpeed: 1390, torque: 46, toolWear: 164, type: "L" },
  { airTemperature: 300.1, processTemperature: 310.2, rotationalSpeed: 1805, torque: 51, toolWear: 153, type: "H" },
  { airTemperature: 296.2, processTemperature: 305.6, rotationalSpeed: 1280, torque: 29, toolWear: 61, type: "M" },
  { airTemperature: 297.3, processTemperature: 307.0, rotationalSpeed: 1450, torque: 34, toolWear: 72, type: "L" },
  { airTemperature: 301.1, processTemperature: 311.4, rotationalSpeed: 1700, torque: 56, toolWear: 206, type: "H" },
  { airTemperature: 299.0, processTemperature: 309.0, rotationalSpeed: 1560, torque: 36, toolWear: 133, type: "M" },
  { airTemperature: 298.5, processTemperature: 308.4, rotationalSpeed: 1670, torque: 40, toolWear: 102, type: "L" },
  { airTemperature: 300.8, processTemperature: 311.0, rotationalSpeed: 1840, torque: 55, toolWear: 182, type: "H" },
  { airTemperature: 297.1, processTemperature: 306.4, rotationalSpeed: 1320, torque: 31, toolWear: 46, type: "M" },
  { airTemperature: 299.7, processTemperature: 310.0, rotationalSpeed: 1480, torque: 43, toolWear: 158, type: "L" },
  { airTemperature: 301.5, processTemperature: 312.1, rotationalSpeed: 1790, torque: 50, toolWear: 199, type: "M" },
  { airTemperature: 298.9, processTemperature: 308.7, rotationalSpeed: 1590, torque: 37, toolWear: 88, type: "H" },
  { airTemperature: 302.4, processTemperature: 313.3, rotationalSpeed: 1725, torque: 48, toolWear: 170, type: "L" },
  { airTemperature: 297.9, processTemperature: 307.7, rotationalSpeed: 1410, torque: 35, toolWear: 55, type: "M" },
];

export const DEMO_BATCH: Prediction[] = DEMO_ROWS.map((row, index) => ({
  ...predict(row),
  equipmentId: ["EQP-2048", "EQP-1193", "EQP-3307", "EQP-0784", "EQP-4481", "EQP-5310", "EQP-2017", "EQP-6204", "EQP-0912", "EQP-7340", "EQP-1642", "EQP-3891", "EQP-4775", "EQP-5164", "EQP-2801", "EQP-6077", "EQP-4128", "EQP-0965", "EQP-7250", "EQP-3388", "EQP-1870", "EQP-5594", "EQP-6431", "EQP-2609"][index],
}))
  .sort((a, b) => b.probability - a.probability);

export function getCostCurve(ratio = 50) {
  const selectedThreshold = clamp(0.18 + (ratio - 50) * 0.00115, 0.08, 0.38);
  return Array.from({ length: 31 }, (_, index) => {
    const threshold = 0.02 + index * 0.01;
    const delta = threshold - selectedThreshold;
    const cost = 244 + delta * delta * 5200 + (threshold < selectedThreshold ? (selectedThreshold - threshold) * ratio * 2.1 : (threshold - selectedThreshold) * 80);
    return { threshold: Number(threshold.toFixed(2)), cost: Math.round(cost), selected: Math.abs(threshold - selectedThreshold) < 0.006 };
  });
}

export function getModelMetrics(ratio = 50) {
  const curve = getCostCurve(ratio);
  const selected = curve.reduce((best, point) => (point.cost < best.cost ? point : best), curve[0]);
  return {
    precision: 0.71,
    recall: 0.84,
    f1: 0.77,
    rocAuc: 0.93,
    prAuc: 0.61,
    expectedCost: selected.cost,
    threshold: selected.threshold,
    confusion: { tp: 54, fn: 10, fp: 22, tn: 1414 },
    failureRate: 3.7,
    evaluatedRows: 1500,
  };
}

export const DEMO_BATCH_NOTE = "Representative challenge preview · replace with preprocessed_challenge.csv for production scoring";
