CREATE TABLE `visual_inspection_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`isEquipment` int NOT NULL,
	`equipmentType` varchar(160) NOT NULL,
	`summary` text NOT NULL,
	`rejectionReason` text NOT NULL,
	`visualAnomalyScore` varchar(32) NOT NULL,
	`confidence` varchar(32) NOT NULL,
	`findingsJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `visual_inspection_history_id` PRIMARY KEY(`id`)
);
