import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const visualInspectionHistory = mysqlTable("visual_inspection_history", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  isEquipment: int("isEquipment").notNull(),
  equipmentType: varchar("equipmentType", { length: 160 }).notNull(),
  summary: text("summary").notNull(),
  rejectionReason: text("rejectionReason").notNull(),
  visualAnomalyScore: varchar("visualAnomalyScore", { length: 32 }).notNull(),
  confidence: varchar("confidence", { length: 32 }).notNull(),
  findingsJson: text("findingsJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VisualInspectionHistory = typeof visualInspectionHistory.$inferSelect;
export type InsertVisualInspectionHistory = typeof visualInspectionHistory.$inferInsert;
