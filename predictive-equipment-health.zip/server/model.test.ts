import { describe, expect, it } from "vitest";
import { DEMO_ROWS, getCostCurve, getModelMetrics, predict } from "../shared/model";
import { appRouter } from "./routers";

describe("predictive equipment model", () => {
  it("flags combined torque and tool wear stress as high risk with observable explanations", () => {
    const result = predict({
      airTemperature: 300.9,
      processTemperature: 310.5,
      rotationalSpeed: 1875,
      torque: 66,
      toolWear: 238,
      type: "M",
    });

    expect(result.probability).toBeGreaterThan(0.18);
    expect(["High", "Critical"]).toContain(result.tier);
    expect(result.explanation).toContain("torque");
    expect(result.explanation).toContain("tool wear");
    expect(result.factors[0]?.feature).toBeDefined();
  });

  it("surfaces out-of-range readings instead of clipping them", () => {
    const result = predict({
      airTemperature: 320,
      processTemperature: 340,
      rotationalSpeed: 900,
      torque: 110,
      toolWear: 420,
      type: "H",
    });

    expect(result.outOfRange).toEqual(expect.arrayContaining([
      "Air temperature",
      "Process temperature",
      "Rotational speed",
      "Torque",
      "Tool wear",
    ]));
    expect(result.confidence).toBeLessThan(0.97);
  });

  it("returns a cost curve and selected operating point for adjustable ratios", () => {
    const curve = getCostCurve(50);
    const metrics = getModelMetrics(50);
    const minimum = Math.min(...curve.map((point) => point.cost));

    expect(curve.length).toBe(31);
    expect(metrics.threshold).toBeGreaterThan(0);
    expect(metrics.threshold).toBeLessThan(1);
    expect(metrics.expectedCost).toBe(minimum);
    expect(getModelMetrics(90).threshold).toBeGreaterThan(metrics.threshold);
  });

  it("serves the representative batch and manual scoring through the router", async () => {
    const caller = appRouter.createCaller({
      user: undefined,
      req: {} as never,
      res: {} as never,
    });
    const batch = await caller.model.batch();
    const prediction = await caller.model.predictManual({
      ...DEMO_ROWS[0],
      threshold: 0.18,
    });

    expect(batch.rows.length).toBeGreaterThan(10);
    expect(batch.total).toBe(750);
    expect(prediction.equipmentId).toBeUndefined();
    expect(prediction.probability).toBeGreaterThan(0);
  });
});
