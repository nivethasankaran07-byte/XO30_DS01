import { beforeEach, describe, expect, it, vi } from "vitest";

const { mockedInvokeLLM } = vi.hoisted(() => ({ mockedInvokeLLM: vi.fn() }));

vi.mock("./_core/llm", () => ({
  invokeLLM: mockedInvokeLLM,
}));

vi.mock("./db", () => ({
  createVisualInspectionHistory: vi.fn(async () => ({ id: 1 })),
  getVisualInspectionHistory: vi.fn(async () => []),
}));

import { appRouter } from "./routers";

describe("model.analyzeVisual", () => {
  const authContext = {
    user: { id: 42, openId: "visual-test-user", name: "Visual Tester", email: "visual@example.com", loginMethod: "test", role: "user" as const, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: {} as never,
    res: {} as never,
  };

  beforeEach(() => {
    mockedInvokeLLM.mockReset();
  });

  it("returns a rejection reason when the image is not equipment", async () => {
    mockedInvokeLLM.mockResolvedValue({
      choices: [{ message: { content: JSON.stringify({
        isEquipment: false,
        equipmentType: "None",
        imageQuality: "good",
        summary: "A landscape photo.",
        rejectionReason: "The image does not show industrial equipment.",
        visualAnomalyScore: 0,
        confidence: 0.99,
        findings: [],
      }) } }],
    });

    const result = await appRouter.createCaller(authContext).model.analyzeVisual({
      imageDataUrl: `data:image/jpeg;base64,${"a".repeat(120)}`,
      fileName: "landscape.jpg",
    });

    expect(result.isEquipment).toBe(false);
    expect(result.rejectionReason).toContain("confidently verified");
    expect(result.fileName).toBe("landscape.jpg");
  });

  it("returns visible findings for an equipment image", async () => {
    mockedInvokeLLM.mockResolvedValue({
      choices: [{ message: { content: JSON.stringify({
        isEquipment: true,
        equipmentType: "Industrial pump",
        imageQuality: "good",
        summary: "Visible surface wear is present near the housing.",
        rejectionReason: "",
        visualAnomalyScore: 0.64,
        confidence: 0.88,
        findings: [{ label: "Surface corrosion", severity: "Medium", evidence: "Brown-orange residue is visible on the outer housing.", action: "Schedule a close visual inspection." }],
      }) } }],
    });

    const result = await appRouter.createCaller(authContext).model.analyzeVisual({
      imageDataUrl: `data:image/jpeg;base64,${"a".repeat(120)}`,
      fileName: "pump.jpg",
    });

    expect(result.isEquipment).toBe(true);
    expect(result.equipmentType).toBe("Industrial pump");
    expect(result.findings[0]?.label).toBe("Surface corrosion");
    expect(result.visualAnomalyScore).toBe(0.64);
  });
});
