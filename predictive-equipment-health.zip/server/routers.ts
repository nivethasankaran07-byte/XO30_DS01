import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { getCostCurve, getModelMetrics, DEMO_BATCH, predict, type EquipmentType } from "../shared/model";
import { invokeLLM } from "./_core/llm";
import { createVisualInspectionHistory, getVisualInspectionHistory } from "./db";
import { z } from "zod";

const sensorInput = z.object({
  airTemperature: z.number(),
  processTemperature: z.number(),
  rotationalSpeed: z.number(),
  torque: z.number(),
  toolWear: z.number(),
  type: z.enum(["H", "L", "M"]),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  model: router({
    metrics: publicProcedure.input(z.object({ ratio: z.number().min(1).max(200).default(50) }).optional()).query(({ input }) => getModelMetrics(input?.ratio ?? 50)),
    costCurve: publicProcedure.input(z.object({ ratio: z.number().min(1).max(200).default(50) })).query(({ input }) => getCostCurve(input.ratio)),
    batch: publicProcedure.query(() => ({ rows: DEMO_BATCH, total: 750, note: "Representative challenge preview" })),
    predictManual: publicProcedure.input(sensorInput.extend({ threshold: z.number().min(0).max(1).default(0.18) })).mutation(({ input }) => {
      const { threshold, ...readings } = input;
      return predict({ ...readings, type: readings.type as EquipmentType }, threshold);
    }),
    history: protectedProcedure.query(({ ctx }) => getVisualInspectionHistory(ctx.user.id)),
    analyzeVisual: protectedProcedure.input(z.object({ imageDataUrl: z.string().min(100), fileName: z.string().optional() })).mutation(async ({ input, ctx }) => {
      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "You are Sentry Ops visual inspection. Use a conservative two-stage gate: first verify the image clearly shows identifiable industrial equipment or machinery, then assess only visible evidence. Reject people, pets, food, landscapes, screenshots, documents, vehicles unrelated to industrial equipment, and unrelated objects. Mark imageQuality as poor when the subject is blurry, too dark, obstructed, too distant, or cropped so heavily that evidence is unreliable. For equipment images, report only findings supported by visible evidence; never invent hidden defects, root causes, or failure mechanism labels. If evidence is uncertain, prefer no finding and explain the limitation. Return JSON only.",
          },
          {
            role: "user",
            content: [
              { type: "text", text: "Analyze this uploaded image for the operator. If it is not industrial equipment, explain why it was rejected. If it is equipment, list visible findings such as corrosion, leak, crack, discoloration, exposed wiring, deformation, residue, or unusual wear. Use cautious language when evidence is uncertain." },
              { type: "image_url", image_url: { url: input.imageDataUrl, detail: "high" } },
            ],
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "equipment_visual_inspection",
            strict: true,
            schema: {
              type: "object",
              properties: {
                isEquipment: { type: "boolean" },
                equipmentType: { type: "string" },
                imageQuality: { type: "string", enum: ["good", "fair", "poor"] },
                summary: { type: "string" },
                rejectionReason: { type: "string" },
                visualAnomalyScore: { type: "number", minimum: 0, maximum: 1 },
                confidence: { type: "number", minimum: 0, maximum: 1 },
                findings: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      label: { type: "string" },
                      severity: { type: "string", enum: ["Low", "Medium", "High"] },
                      evidence: { type: "string" },
                      action: { type: "string" },
                    },
                    required: ["label", "severity", "evidence", "action"],
                    additionalProperties: false,
                  },
                },
              },
              required: ["isEquipment", "equipmentType", "imageQuality", "summary", "rejectionReason", "visualAnomalyScore", "confidence", "findings"],
              additionalProperties: false,
            },
          },
        },
      });

      const content = response.choices?.[0]?.message?.content;
      const raw = typeof content === "string" ? content : "{}";
      try {
        const candidate = JSON.parse(raw) as {
          isEquipment?: boolean;
          equipmentType?: string;
          imageQuality?: "good" | "fair" | "poor";
          summary?: string;
          rejectionReason?: string;
          visualAnomalyScore?: number;
          confidence?: number;
          findings?: Array<{ label: string; severity: "Low" | "Medium" | "High"; evidence: string; action: string }>;
        };
        const accepted = candidate.isEquipment === true && (candidate.confidence ?? 0) >= 0.6 && candidate.imageQuality !== "poor" && Boolean(candidate.equipmentType && candidate.equipmentType !== "Unknown");
        const parsed = accepted ? {
          isEquipment: true,
          equipmentType: candidate.equipmentType!,
          imageQuality: candidate.imageQuality!,
          summary: candidate.summary ?? "Visible equipment evidence was analyzed.",
          rejectionReason: "",
          visualAnomalyScore: candidate.visualAnomalyScore ?? 0,
          confidence: candidate.confidence ?? 0,
          findings: candidate.findings ?? [],
          fileName: input.fileName ?? "uploaded image",
        } : {
          isEquipment: false,
          equipmentType: candidate.equipmentType ?? "Unknown",
          imageQuality: candidate.imageQuality ?? "poor",
          summary: "The image did not pass the conservative equipment and image-quality gate.",
          rejectionReason: candidate.imageQuality === "poor" ? "The image is not clear enough to analyze reliably. Upload a sharper, better-lit equipment photo." : "The image could not be confidently verified as identifiable industrial equipment.",
          visualAnomalyScore: 0,
          confidence: candidate.confidence ?? 0,
          findings: [],
          fileName: input.fileName ?? "uploaded image",
        };
        const saved = await createVisualInspectionHistory({
          userId: ctx.user.id,
          fileName: parsed.fileName,
          isEquipment: parsed.isEquipment ? 1 : 0,
          equipmentType: String(parsed.equipmentType ?? "Unknown"),
          summary: String(parsed.summary ?? ""),
          rejectionReason: String(parsed.rejectionReason ?? ""),
          visualAnomalyScore: String(parsed.visualAnomalyScore ?? 0),
          confidence: String(parsed.confidence ?? 0),
          findingsJson: JSON.stringify(parsed.findings ?? []),
        });
        return { ...parsed, historyId: saved?.id ?? null };
      } catch {
        const fallback = {
          isEquipment: false,
          equipmentType: "Unknown",
          summary: "The image could not be confidently analyzed.",
          rejectionReason: "Please upload a clear photo of industrial equipment.",
          visualAnomalyScore: 0,
          confidence: 0.2,
          findings: [],
          fileName: input.fileName ?? "uploaded image",
        };
        await createVisualInspectionHistory({
          userId: ctx.user.id,
          fileName: fallback.fileName,
          isEquipment: 0,
          equipmentType: fallback.equipmentType,
          summary: fallback.summary,
          rejectionReason: fallback.rejectionReason,
          visualAnomalyScore: "0",
          confidence: "0.2",
          findingsJson: "[]",
        });
        return { ...fallback, historyId: null };
      }
    }),
  }),
});

export type AppRouter = typeof appRouter;
